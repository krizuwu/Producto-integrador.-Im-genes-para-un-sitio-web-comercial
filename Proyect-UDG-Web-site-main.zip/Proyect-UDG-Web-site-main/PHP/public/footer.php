   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Categorias</p> <hr>
					<ul>
						<li><a href="signin.php">Busca a tu doctor</a></li>
						<li><a href="signin.php">Contacto</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contacto</p> <hr>
						<p>Núcleo de Tratamientos psicologicos <br>
							ades@clinicades.com <br>
							Telefono: 973869824232</p>
							<br>
						<span style="color: white;font-size: 15px">&copy;<?php echo date('Y'); ?>-Todos los derechos Reservados</span>
					</div>
					<div class="col-md-4 share_img">
					<p>Siguenos en nuestras redes</p> <hr>
						<a href="" ><img src="img/fb-free.png" alt="facebok"></a>
						<a href=""><img src="img/gogle-plud-free.png" alt="google-plus"></a>
						<a href=""><img src="img/twitter.png" alt="twitter"></a>
						
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
