<?php include('header.php'); ?>

<?php include('admin/function.php'); ?>



	<!-- this is for donor registraton -->
<h1 class="text-center" style="background-color:#16bfb2;color: #fff; height: 40px; font-family: 'Poppins', sans-serif;">Inicia Sesion </h1>
	<div class="main_content" style="background-color:#fff;">

		<div class="col-md-12">
			<div class="box1" style="float: left;margin-left: 325px;">
				<h4 class="text-center;" ><a href="patient_login.php" style="text-decoration: none;color:red;">I am Patient</a></h4>
			</div>
			
			<div class="box2" style="float: right;margin-right: 385px;">
				<h4 class="text-center;"><a href="#" style="text-decoration: none;color:red;">I am Doctor</a></h4>
			</div>
			
		</div>



		
          
    </div><br><br><br><br>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>