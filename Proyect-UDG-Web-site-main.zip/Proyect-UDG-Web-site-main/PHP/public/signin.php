<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
<h1 class="text-center" style="background-color:#16bfb2;color: #fff; height: 40px; font-family: 'Poppins', sans-serif;">Inicia Sesión </h1>
	<div class="main_content" style="background-color:#fff;">
		<div class="formstyles" style="background-color: #101011;color: #0d0623;">
				<div class="col-md-12">
					
					<div class="col-md-4"></div>
					
					<div class="col-md-4" style="float: right;padding:40px 115px;border: 1px solid lightgrey;margin-right:415px; margin-bottom:50px;background-color:#f3f3f8;color:#141313;">
						
						<button><a class="btn-login" href="patient_login.php">Login Pacientes</a></button> <br> <br>
						<button><a class="btn-login" href="doctors/doctorlogin.php">Login Doctores</a></button>
					</div>
					
					<div class="col-md-4"></div>
					
					
					
				</div>



		
          
    </div><br><br><br><br>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>