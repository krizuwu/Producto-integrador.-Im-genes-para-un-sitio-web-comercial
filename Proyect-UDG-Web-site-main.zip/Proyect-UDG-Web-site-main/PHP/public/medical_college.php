<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="form-group mc">
<h1 class="text-center" style="background-color:#16bfb2;color: #fff; height: 40px; font-family: 'Poppins', sans-serif;">Nuestra Clinica </h1>

                              <table cellpadding="10" cellspacing="10" class="table table-hover">   

                                  <tr>
                                      <th>No.</th><th>Name</th><th>Acronym</th><th>Established</th><th>Location</th><th>website</td>
                                  </tr>
                                  
                              </table>
	</div>
	<div class="">
		<div class="row">
			<div class="col-6">
			<img src="./Ubicacion.PNG" alt="">
			</div>
		
			<div class="col-6">	
				<div class="card" style="width: 30rem;">
                <div class="card-body">
                 <h5 class="card-title">Schedules </h5>
                   <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                      <p class="card-text">Monday to Saturday from 9am to 7pm</p>
                      <br>
                      <p class="card-text">Sunday closed</p>
  
                 </div>
            </div>
	  </div>
  </div>
</div>
	

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
		<!-- footer section Ends--> 


	
	</div><!--  containerFluid Ends -->



	<script src="js/bootstrap.min.js"></script>
	
</body>
</html>